let MYSQL_CONFIG = {};

MYSQL_CONFIG = {
  host: 'localhost',
  user: 'root',
  password: 'woshihamo',
  port: 3306,
  database: 'myblog'
}

module.exports = {
  MYSQL_CONFIG
}